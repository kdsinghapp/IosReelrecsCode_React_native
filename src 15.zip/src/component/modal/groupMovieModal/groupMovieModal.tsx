import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    Modal,
    TouchableOpacity,
    StyleSheet,
    FlatList,
    Image,
    TouchableNativeFeedback,
    Dimensions,
} from 'react-native';
import Slider from '@react-native-community/slider';
import imageIndex from '../../../assets/imageIndex'; // Update with your correct path
import { Color } from '../../../theme/color';
import font from '../../../theme/font';
import { wp } from '../../../utils/Constant';
import BlurViewCom from '../../common/BlurViewCom/BlurViewCom';
import { BASE_IMAGE_URL } from '../../../redux/Api/axiosInstance';
import FastImage from 'react-native-fast-image';



const GroupMovieModal = ({ visible, onClose, setTotalFilterApply, group, groupId, token, filterFunc, groupTotalMember }) => {
    const [selectedUsers, setSelectedUsers] = useState<number[]>([]);
    const [userSectionOpen, setUserSectionOpen] = useState(true);
    const [groupSectionOpen, setGroupSectionOpen] = useState(true);
    const [groupValue, setGroupValue] = useState(0);
    const [sliderWidth, setSliderWidth] = useState(1);
    const group_members = group?.members
    console.log(group.members, "<-----group data with members")
    let countfilter = 0
    const toggleUser = (id: number) => {
        setSelectedUsers(prev =>
            prev.includes(id) ? prev.filter(uid => uid !== id) : [...prev, id]
        );
    };
    useEffect(() => {
        // const totalFilterClount  = ()=> {
        if (groupValue > 0) {
            countfilter = 1
        }
        countfilter = selectedUsers.length + countfilter
        setTotalFilterApply(countfilter)
        // console.log(selectedUsers, "<-----selectedUsers___--->")
        // console.log(countfilter, "countfilter  -  -")
        // console.log(groupValue, "groupValue  -  -")

        // }
    }, [selectedUsers, groupValue])
const THUMB_SIZE = 18;      // approx white dot size
const BUBBLE_WIDTH = 50;   // adjust to your bubble width

const getBubbleLeft = () => {
  const ratio = groupValue / groupTotalMember;
  const usableWidth = sliderWidth - THUMB_SIZE;
  return ratio * usableWidth - BUBBLE_WIDTH / 3 + THUMB_SIZE ;
};

    const resetFilters = () => {
        setSelectedUsers([]);
        setGroupValue(0);
        countfilter = 0;
        onClose()
    };

    return (


        <Modal animationType="slide"
            transparent
            visible={visible}
            onRequestClose={onClose}
        >

            <TouchableOpacity style={styles.overlay} onPress={() => onClose()} >

                <TouchableNativeFeedback>



                    <View style={styles.modalContent}>
                        {/* <BlurViewCom /> */}

                        {/* Header */}
                        <View style={styles.header}>
                            <Text style={styles.modalTitle}>Filter</Text>
                            <TouchableOpacity onPress={onClose}>
                                <Image source={imageIndex.closeimg} style={styles.closeIcon} />
                            </TouchableOpacity>
                        </View>

                        {/* Liked by User Section */}
                        <TouchableOpacity
                            activeOpacity={0.8} // Opacity when pressed
                            style={styles.sectionHeader}
                            onPress={() => setUserSectionOpen(!userSectionOpen)}
                        >
                            <Text style={styles.sectionTitle}>Liked by User</Text>
                            {/* <Text>{userSectionOpen ? '▾' : '▸'}</Text> */}
                            {userSectionOpen ? <Image source={imageIndex.arrowUp} style={styles.arrowStyle} /> : <Image source={imageIndex.arrowDown} style={styles.arrowStyle} />}
                        </TouchableOpacity>
                        <View style={{ maxHeight: '35%' }} >
                            {userSectionOpen && (
                                <FlatList
                                    data={group_members}
                                    keyExtractor={item => item?.username.toString()}
                                    renderItem={({ item }) => {
                                        const selected = selectedUsers.includes(item?.username);
                                        return (
                                            <View style={styles.userItem}>
                                                {/* <Image source={{ uri: `${BASE_IMAGE_URL}${item?.avatar}` }} style={styles.avatar} /> */}
                                                 <FastImage
          style={styles.avatar}
          source={{
          uri: `${BASE_IMAGE_URL}${item?.avatar}` ,
            priority: FastImage.priority.low, // 👈 Low priority (since profile image small)
            cache: FastImage.cacheControl.immutable, // 👈 Cache permanently
          }}
          resizeMode={FastImage.resizeMode.cover}
        />
                                                <Text style={styles.userName}>{item?.name}</Text>
                                                <TouchableOpacity onPress={() => toggleUser(item?.username)}>
                                                    <Image
                                                        source={
                                                            selected
                                                                ? imageIndex.checKBoxActive
                                                                : imageIndex.checkBox
                                                        }
                                                        style={styles.checkboxIcon}
                                                    />
                                                </TouchableOpacity>
                                            </View>
                                        );
                                    }}
                                    initialNumToRender={10}
                                    maxToRenderPerBatch={10}
                                    windowSize={7}
                                    removeClippedSubviews

                                />
                            )}
                        </View>
                        {/* Liked by Group Section */}
                        <TouchableOpacity
                            activeOpacity={0.8} // Opacity when pressed

                            style={styles.sectionHeader}
                            onPress={() => setGroupSectionOpen(!groupSectionOpen)}
                        >
                            <Text style={styles.sectionTitle}>Liked by Group</Text>
                            {groupSectionOpen ? <Image source={imageIndex.arrowUp} style={styles.arrowStyle} /> : <Image source={imageIndex.arrowDown} style={styles.arrowStyle} />}

                            {/* <Text>{groupSectionOpen ? '▾' : '▸'}</Text> */}
                        </TouchableOpacity>
                        {groupSectionOpen && (
                            // <View style={{paddingHorizontal:20,}} >
                            <View style={styles.sliderSection}>
                                <Text style={[styles.groupValue, {}]}>0</Text>

                                <View
                                    style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}
                                    onLayout={e => setSliderWidth(e.nativeEvent.layout.width)}
                                >
                                    {sliderWidth > 0 && (
                                        <View
                                            style={[
                                                styles.valueBubble,

                                                {
                                                    left:getBubbleLeft(),
                                                 },
                                            ]}
                                        >
                                            <Text style={styles.bubbleText}>{groupValue}</Text>
                                            <View style={styles.arrowDown} />
                                            <Image
                                                source={imageIndex.thumpUP}
                                                resizeMode="contain"
                                                style={styles.thumpImg}
                                            />
                                        </View>
                                    )}
                                    <Slider
                                        style={styles.slider}
                                        minimumValue={0}
                                        maximumValue={groupTotalMember}
                                        step={1}
                                        value={groupValue}
                                        onValueChange={value => setGroupValue(value)}
                                        minimumTrackTintColor={Color.primary}
                                        maximumTrackTintColor="#ccc"
                                        thumbTintColor={Color.whiteText}
                                    />
                                </View>

                                <Text style={[styles.groupValue, {}]}>{groupTotalMember}</Text>
                            </View>
                            // </View>
                        )}


                        {/* Footer buttons */}
                        <View style={styles.bottomButtonContainerBox}  >
                            <View style={styles.bottomButtonContainer}>
                                <TouchableOpacity onPress={resetFilters} style={styles.selectButton}>
                                    <Text style={[styles.buttonTxt, { fontFamily: font.PoppinsMedium }]} >Reset</Text>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={() => {
                                    onClose();
                                    filterFunc(selectedUsers, groupValue);
                                }} style={styles.cancelButton}>
                                    <Text style={styles.buttonTxt} >Apply</Text>
                                </TouchableOpacity>

                            </View>
                        </View>
                    </View>

                </TouchableNativeFeedback>
            </TouchableOpacity>
        </Modal>
    );
};

const styles = StyleSheet.create({
    overlay: {
        flex: 1,
        justifyContent: 'flex-end',
        backgroundColor: 'rgba(0,0,0,0.2)',
    },
    modalContent: {
        backgroundColor: Color.modalTransperant,
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        paddingTop: 20,
        maxHeight: '75%',
        minHeight: '75%',
        // justifyContent: 'flex-end',
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 20,
        paddingHorizontal: 20,

    },
    modalTitle: {
        fontSize: 18,
        color: 'white',
         textAlign: 'center',
        flex: 1,
        fontFamily:font.PoppinsBold
    },
    closeIcon: {
        width: 18,
        height: 18,
        // tintColor: 'white',
    },
    sectionHeader: {
        bottom: 0,
        // position:'absolute',
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical: 14,
        paddingHorizontal: 20,
        marginVertical: 10,
        backgroundColor: Color.grey,
        borderRadius: 10,
        marginHorizontal: 20,
    },
    sectionTitle: {
        fontSize: 14,
        color: Color.whiteText,
        fontFamily: font.PoppinsBold,
    },
    userItem: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 10,
        paddingHorizontal: 20,

        // maxHeight:'60%',
    },
    avatar: {
        width: 32,
        height: 32,
        borderRadius: 16,
        marginRight: 10,
    },
    userName: {
        flex: 1,
        color: 'white',
        fontSize: 16,
        fontFamily:font.PoppinsMedium
    },
    checkboxIcon: {
        width: 20,
        height: 20,
    },

    groupIcon: {
        width: 24,
        height: 24,
        marginRight: 10,
    },

    groupValue: {
        // width: 30,
        color: 'white',
        textAlign: 'center',

    },
    footer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingTop: 20,
        right: 20,
        left: 20,
        backgroundColor: 'red',
        bottom: 20,
        position: 'relative',
    },
    resetButton: {
        flex: 1,
        marginRight: 10,
        backgroundColor: '#333',
        borderRadius: 10,
        padding: 15,
        alignItems: 'center',
    },
    applyButton: {
        flex: 1,
        backgroundColor: '#007BFF',
        borderRadius: 10,
        padding: 15,
        alignItems: 'center',
    },
    resetButtonText: {
        color: 'white',
        fontWeight: 'bold',
    },
    applyButtonText: {
        color: 'white',
        fontWeight: 'bold',
    },


    sliderSection: {
        flexDirection: 'row',
        alignItems: 'center',
        marginVertical: 20,
        paddingHorizontal: 10,
        marginHorizontal: 20,

    },



    slider: {
        width: wp(80),
        height: 40,
    },
    arrowStyle: {
        height: 22,
        width: 22,
        resizeMode: "contain",
        tintColor: Color.primary,
    },
    valueBubble: {
        flexDirection: 'row',
        alignSelf: 'center',
        justifyContent: 'center',
        padding: 4,
        position: 'absolute',
        bottom: 40,
        backgroundColor: Color.primary,
        alignItems: 'center',
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 8,
        transform: [{ translateX: -15 }],
        zIndex: 10,
        borderRightColor: 'red'
    },
    thumpImg: {
        height: 18,
        width: 18,
        marginLeft: -10,

    },
    bubbleText: {
     color: Color.whiteText,
  fontSize: 12,
  fontFamily: font.PoppinsMedium,
  textAlign: 'center',
  includeFontPadding: false,   // Android fix
  textAlignVertical: 'center', // Android fix 
  bottom:-2
     },
    arrowDown: {
        width: 0,
        height: 0,
        borderLeftWidth: 7,
        borderRightWidth: 7,
        borderTopWidth: 7,
        borderLeftColor: 'transparent',
        borderRightColor: 'transparent',
        borderTopColor: Color.primary,
        top: 16, 
        //   marginTop: -5,
    },
    bottomButtonContainerBox: {
        height: 90,
        bottom: 20,
        position: 'absolute',
        right: 20,
        left: 20,
        width: Dimensions.get('window').height * 1,
        // paddingHorizontal: 20,
        backgroundColor: "rgba(26, 26, 26,0.8)",
    },
    bottomButtonContainer: {
        // 
        flexDirection: 'row',
        marginBottom: 14,
        marginTop: 24,
        width: '42%',
        // alignSelf: 'flex-end',
        justifyContent: 'space-between',
    },
    selectButton: {
        width: '46%',

        // backgroundColor: Color.primary,
        // backgroundColor:Color.modalBg,
        borderWidth: 0.5,
        borderColor: Color.textGray,
        borderRadius: 8,

        alignItems: 'center',
        justifyContent: 'center',
        paddingHorizontal: 24,
        paddingVertical: 6,
    },
    cancelButton: {
        // borderColor:Color.whiteText,
        backgroundColor: Color.primary,
        width: '47%',

        borderRadius: 8,
        alignItems: 'center',
        justifyContent: 'center',
        paddingHorizontal: 24,
        paddingVertical: 10,
        borderWidth: 1,
        marginLeft: 15
    },
    buttonTxt: {
        color: Color.whiteText,
        fontFamily: font.PoppinsBold,
        fontSize: 14,
        // marginVertical:20,
    }
});

export default GroupMovieModal;

