import React, { useEffect, useState } from 'react';
import {
  Modal,
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Image,
  Dimensions,
} from 'react-native';
import imageIndex from '../../../assets/imageIndex';
import { Color } from '../../../theme/color';
import font from '../../../theme/font';
import CustomText from '../../common/CustomText';

interface Episode {
  id: number;
  title: string;
  duration: string;
  image: string;
}

interface Props {
  visible: boolean;
  onClose: () => void;
  episodes: Episode[];
  selectedId: number;
  onSelect: (id: number) => void;
  token: string;
  imdb_id: string;
  onFetchEpisodes: (season: number) => void;
}





export const sessionData = [
  {
    id: 1,
    session: "Session 1",

  },
  {
    id: 2,
    session: "Session 2",

  },
  {
    id: 3,
    session: "Session 3",

  },

]


const EpisodesModal: React.FC<Props> = ({
  visible,
  onClose,
  episodes,
  selectedId,
  onSelect,
  token,
  imdb_id,
  sessionList,
  onFetchEpisodes,
}) => {
  const [sessionOption, setSessionOption] = useState(false)

  const [selectedSortId, setSelectedSortId] = useState(sessionData[0]?.session || "session 1");
  // console.log(sessionList, "datao",imdb_id)
  useEffect(() => {
    if (visible) {
      onFetchEpisodes(4);
      // optionally setSelectedSortId("Session 1");
    }
  }, [visible]);

  const renderItem = ({ item }: { item: Episode }) => {
console.log("item",item)

    const isSelected = item.id === selectedId;
    return (
      <TouchableOpacity
        style={[styles.episodeContainer,]}
        onPress={() => onSelect(item?.id)}
      >
        <Image source={imageIndex.videoPlay}

          resizeMode='contain'
          style={styles.thumbnail} />
        <View style={styles.textContainer}>

          <CustomText
            numberOfLines={2}
            size={14}
            color={Color.whiteText}
            style={[
              styles.title,
              {
                color: item?.id === 2 ? Color.lightPrimary : Color.whiteText,
                fontFamily: item?.id === 2 ? font.PoppinsBold : font.PoppinsMedium

              }
            ]}
            font={font.PoppinsBold}
          >
            {item?.title}
          </CustomText>


          <CustomText
            size={14}
            color={Color.placeHolder}
            style={styles.duration}
            font={font.PoppinsRegular}
          >
            {item.duration}
          </CustomText>
        </View>
      </TouchableOpacity>
    );
  };


  const GenreButton = ({ title, onPress }: any) => (
    <TouchableOpacity
      style={[styles.genreButton]}
      onPress={() => { onPress(); setSessionOption(false) }}
    >
      <CustomText
        size={14}
        color={Color.whiteText}
        style={[styles.genreText,]}
        font={font.PoppinsRegular}
      >
        {title?.session}
      </CustomText>

      <View style={{
        borderBottomWidth: 1,
        borderColor: Color.whiteText,
        width: 156,
        // marginTop: 12,
        alignItems: "center",
        justifyContent: "center"
      }} />
    </TouchableOpacity>
  );



  return (
    <Modal animationType="slide" transparent visible={visible} onRequestClose={onClose} >
      <TouchableOpacity style={styles.overlay} onPress={onClose} >
        <View style={styles.modalContent}>
          <View style={styles.header}>
            <Text style={styles.headerText}></Text>
            <CustomText
              size={16}
              color={Color.whiteText}
              style={styles.headerText}
              font={font.PoppinsBold}
            >
              Episodes
            </CustomText>
            <TouchableOpacity onPress={onClose}>
              <Image source={imageIndex.closeimg} style={{
                height: 24,
                width: 24,
                resizeMode: "contain"
              }} />
            </TouchableOpacity>

          </View>

          <TouchableOpacity
            activeOpacity={0.8} // Opacity when pressed

            style={styles.sectionHeader}
            onPress={() => setSessionOption(!sessionOption)}
          >
            <CustomText
              size={16}
              color={Color.whiteText}
              style={styles.sectionTitle}
              font={font.PoppinsBold}
            >
              {selectedSortId}
            </CustomText>
            {sessionOption ? <Image source={imageIndex.arrowUp} style={styles.arrowStyle} /> : <Image source={imageIndex.arrowDown} style={styles.arrowStyle} />}


          </TouchableOpacity>

          {sessionOption ? (
            <FlatList
              data={sessionList} // ✅ use dynamic list
              showsVerticalScrollIndicator={false}
              keyExtractor={(item) => item.id.toString()}
              renderItem={({ item }) => (
                <GenreButton
                  title={item}
                  onPress={() => {
                    setSelectedSortId(item?.session);
                    onFetchEpisodes(item?.id);  // Fetch that season's episodes
                    setSessionOption(false);
                  }}
                  isSelected={selectedSortId === item?.session}
                />
              )}
              initialNumToRender={10}
              maxToRenderPerBatch={10}
              windowSize={12}
              removeClippedSubviews

            />
          ) :

            <FlatList
              showsVerticalScrollIndicator={false}
              style={{
                marginTop: 12
              }}
              data={episodes}
              renderItem={renderItem}
              keyExtractor={(item) => item.id.toString()}
              contentContainerStyle={styles.list}
              initialNumToRender={10}
              maxToRenderPerBatch={10}
              windowSize={7}
              removeClippedSubviews

            />
          }

         


        </View>
      </TouchableOpacity>
    </Modal>
  );
};
// good time to see
export default EpisodesModal;

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: Color.modalBg,
    paddingTop: 16,
    paddingBottom: 12,
    paddingHorizontal: 16,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    // height:  Dimensions.get('window').height * 0.7,
    maxHeight: Dimensions.get('window').height * 0.66,
    height: Dimensions.get('window').height * 0.66,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
    marginTop: 12

  },
  headerText: {
    color: Color.whiteText,
  },

  episodeContainer: {
    flexDirection: 'row',
    marginBottom: 12,
    borderRadius: 10,
    overflow: 'hidden',
    marginVertical: 3
  },

  thumbnail: {
    width: 127,
    height: 72,
  },
  textContainer: {
    paddingLeft: 10,
    // justifyContent: 'center',
  },
  title: {
  },
  titleSelected: {
    color: Color.primary,
  },
  duration: {
    marginTop: 2
  },
  list: {
    paddingBottom: 16,
  },
  sectionHeader: {
    bottom: 0,
    // position:'absolute',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 14,
    paddingHorizontal: 20,
    marginVertical: 10,
    backgroundColor: Color.grey,
    borderRadius: 10,
    // marginHorizontal:20,
  },
  sectionTitle: {
    fontSize: 14,
    color: Color.whiteText,
    fontFamily: font.PoppinsBold,
    textAlign: 'center',
    flex: 1,
  },
  arrowStyle: {
    height: 22,
    width: 22,
    resizeMode: "contain",
    tintColor: Color.primary,
  },
  genreButton: {
    alignItems: 'center',
    paddingTop: 10,
  },
  genreText: {
    marginBottom: 18,
  },
});



