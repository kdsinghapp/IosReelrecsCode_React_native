import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const SettingLogOut = () => {
  return (
    <View>
      <Text>SettingLogOut</Text>
    </View>
  )
}

export default React.memo(SettingLogOut)

const styles = StyleSheet.create({})