export default {
    // PoppinsBlack: 'Poppins-Black',
    // PoppinsBlackItalic: 'Poppins-BlackItalic',
    PoppinsBold: 'Poppins-Bold',
    PoppinsRegular: 'Poppins-Regular',
    PoppinsMedium: 'Poppins-Medium',
    PoppinsExtraBold: 'Poppins-ExtraBold',

    PoppinsSemiBold: 'Poppins-SemiBold',
    // PoppinsSemiBoldItalic: 'Poppins-SemiBoldItalic',
    PoppinsThin: 'Poppins-Thin',
    PoppinsThinItalic: 'Poppins-ThinItalic',
    sackersgothicstdheavy: 'sackersgothicstd-heavy',
    sackersgothicstdlight: 'sackersgothicstd-light',
    sackersgothicstdmedium: 'sackersgothicstd-medium',
        PoppinsExtraBoldItalic: 'Poppins-ExtraBoldItalic',
    PoppinsExtraLightItalic: 'Poppins-ExtraLightItalic',
  };

//    allowFontScaling={false} 