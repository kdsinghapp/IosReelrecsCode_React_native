
// import { Dimensions, StyleSheet } from 'react-native';
// import { hp, wp } from '@utils/Constant';
// import { Color } from '@theme/color';
// import ResponsiveSize from '@utils/ResponsiveSize';
// // login
// const styles = StyleSheet.create({
//   mainView: { flex: 1, backgroundColor: Color.background },
//   text: {
//     fontSize: 16,
//     lineHeight: 24,
//     fontWeight: '700',
//     color: Color.primary,
//     bottom: 2,
//   },
//   inputView: { marginTop: Dimensions.get('window').height * 0.04 
    
//    },
//   txtHeading: {
//     color: Color.whiteText,
//     textAlign: "center",
//     marginTop: 6,

//   },
//   loginHeading: {
//     color: Color.whiteText,
//     textAlign: "center",
//     fontSize: 24,
//     // bottom: 5
//   },
//   emailError:{
//     color:'red', alignSelf:'center', top:10,
//   },
//   imgLogo: {
//     height: 40, width: 40,
//     resizeMode: "contain"
//   },

//   titlView: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     marginTop: 20,
//     alignSelf: 'center',
//     justifyContent: 'flex-start',
//      marginBottom: 50,
//     marginHorizontal: 15,
//   },
//   redText: {
//     color: 'red', 
//   },
//   pass: { 
//     color: Color.primary,
//     fontSize: 14,
//     lineHeight: 18,
//     textAlign: "right"
//   },
//   viewCont: {
//     marginHorizontal: 16,

//     flex: 1,
//     marginTop: hp(10)
//   },
//   iconButton: {
//     padding: 8,
//     borderRadius: 10,
//    },
//   iconImage: {
//     height: 33,
//     width: 33,
//     resizeMode: 'contain',
//   },
//   tite:{
//     fontSize: 16, lineHeight: 20, color: Color.whiteText,  
//   },
//   subTitle: { lineHeight: 16, marginTop: 33, marginBottom: 15, fontSize: 16, color: Color.whiteText, textAlign: "center", fontWeight: "700" }
// });
// export default styles;
