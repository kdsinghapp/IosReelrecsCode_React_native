// import { useNavigation } from '@react-navigation/native';
// import { useEffect, useState } from 'react';
// import { Alert } from 'react-native';
// import { getRatedMovies } from '../../../../redux/Api/movieApi';
// import { useSelector } from 'react-redux';
// import { RootState } from '../../../../redux/store';
// import AsyncStorage from '@react-native-async-storage/async-storage';
// import { getHistoryApi } from '../../../../redux/Api/ProfileApi';

// const useRanking = () => {
//   const navigation = useNavigation();
//   const token = useSelector((state: RootState) => state.auth.token);
//   const [isVisible, setIsVisible] = useState<boolean>(false);
//   const [stepsModal, setStepsModal] = useState<boolean>(false);
//   const [lovedImge, setlovedImge] = useState<boolean>(false);
//   const [selectedPlatforms, setSelectedPlatforms] = useState<any[]>([]);

  
 
  
 

//   return {
//     navigation,
//     isVisible, setIsVisible,
   
//     lovedImge, setlovedImge,
//     selectedPlatforms, setSelectedPlatforms,
//     stepsModal, setStepsModal
//   };
// };
// export default useRanking;
